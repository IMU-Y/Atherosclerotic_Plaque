import torch
import torch.nn as nn

from model.my_unet_parts import DoubleConv
from model.unet_parts import Up, OutConv
from model.vit import ViT
from einops import rearrange


class ResidualBlock(nn.Module):
    def __init__(self, in_channels, out_channels, stride=2):
        super(ResidualBlock, self).__init__()

        # 第一个卷积层
        self.conv1 = nn.Conv2d(in_channels, out_channels, kernel_size=3, stride=stride, padding=1)
        self.bn1 = nn.BatchNorm2d(out_channels)
        self.relu = nn.ReLU(inplace=True)

        # 第二个卷积层
        self.conv2 = nn.Conv2d(out_channels, out_channels, kernel_size=3, stride=1, padding=1)
        self.bn2 = nn.BatchNorm2d(out_channels)

        # 如果维度不同，使用适当的卷积进行调整
        self.adjust_dimensions = nn.Conv2d(in_channels, out_channels, kernel_size=1, stride=stride, padding=0)

    def forward(self, x):
        residual = x

        # 第一个卷积块
        out = self.conv1(x)
        out = self.bn1(out)
        out = self.relu(out)

        # 第二个卷积块
        out = self.conv2(out)
        out = self.bn2(out)

        _, _, h, w = x.size()
        out = out[:, :, :h//2, :w//2]

        # 调整维度
        if x.size(1) != out.size(1) or x.size(2) != out.size(2):
            residual = self.adjust_dimensions(x)
        residual=residual[:, :, :h//2, :w//2]

        # 残差连接
        out += residual
        out = self.relu(out)

        return out

class TransUnet(nn.Module):
    def __init__(self, all_in_channels,img, in_channels=512, embedding_dim=1024, head_num=8, mlp_dim=1024,
                 block_num=6, patch_dim=2, classification=True, num_classes=5, bilinear=True, output_channels=5):
        super(TransUnet, self).__init__()
        self.all_in_channels = all_in_channels
        self.output_channels = output_channels
        self.norm = nn.BatchNorm2d

        # 370*370*64
        self.inc = DoubleConv(self.all_in_channels,64)
        # 185*185*128
        self.down1=ResidualBlock(64,128)
        # 92*92*256
        self.down2=ResidualBlock(128,256)
        # 46*46*512
        self.down3=ResidualBlock(256,512)
        self.input_vit=img//2//2//2
        # 23*23*1024
        self.vision=ViT(img_dim=self.input_vit, in_channels=512, embedding_dim=1024, head_num=8, mlp_dim=1024,
                 block_num=6, patch_dim=2, classification=False, num_classes=5)
        self.conv1 = DoubleConv(1024, 512)
        self.conv2 = DoubleConv(512,256)
        self.conv3 = DoubleConv(256, 128)
        self.conv4 = DoubleConv(128, 64)
        self.up1 = Up(1024, 512, bilinear)
        self.up2 = Up(512, 256, bilinear)
        self.up3 = Up(256, 128, bilinear)
        self.up4 = Up(128, 64, bilinear)
        self.out = OutConv(64, self.output_channels)

    def forward(self,x):
        x0 = self.inc(x)
        x1 = self.down1(x0)
        x2 = self.down2(x1)
        x3 = self.down3(x2)
        x4 = self.vision(x3)
        x4 = rearrange(x4, "b (x y) c -> b c x y", x=self.input_vit//2, y=self.input_vit//2)
        x5 = self.conv1(x4)
        x = self.up1(x5, x3)
        x = self.conv2(x)
        x = self.up2(x, x2)
        x = self.conv3(x)
        x = self.up3(x, x1)
        x = self.conv4(x)
        x = self.up4(x, x0)
        x = self.out(x)
        return x







